package com.task;

import com.task.constants.ENTRY_GATE;
import com.task.constants.EXIT_GATE;
import com.task.constants.OCCUPIED_STATUS;
import com.task.constants.VEHICLE_TYPE;
import com.task.gate.EntryGate;
import com.task.gate.ExitGate;
import com.task.model.Floor;
import com.task.model.History;
import com.task.model.Slot;
import com.task.vehicle.Vehicle;
import com.task.util.DateTime;
import com.task.util.Utils;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.PriorityBlockingQueue;

import static com.task.constants.ENTRY_GATE.*;
import static com.task.constants.EXIT_GATE.*;
import static com.task.constants.VEHICLE_TYPE.*;

class PriorityComparator implements Comparator<Vehicle> {

    Map<VEHICLE_TYPE, Integer> priorityMap;

    public PriorityComparator(Map<VEHICLE_TYPE, Integer> priorityMap) {
        this.priorityMap = priorityMap;
    }

    private int getPriority(Vehicle vehicle) {
        return priorityMap.get(vehicle.getVehicleType());
    }

    @Override
    public int compare(Vehicle o1, Vehicle o2) {
        int p1 = getPriority(o1);
        int p2 = getPriority(o2);
        if (p1 == p2)
            return 0;
        else if (p1 >= p2)
            return 1;
        return -1;
    }
}

public class PettahMultiStoryCarParkManager implements CarParkManager {

    private static final int NUMBER_OF_FLOORS = 9;
    private static final int ENTRY_GATE_QUEUE_CAPACITY = 5;
    public static final Floor[] floors = new Floor[NUMBER_OF_FLOORS];
    private static int currentlyParkedVehicleCount = 0;
    private static History history;
    private final EntryGate entryGateNorth1, entryGateNorth2, entryGateWest1, entryGateWest2, entryGateWest3;
    private final ExitGate exitGateSouth1, exitGateSouth2, exitGateEast1, exitGateEast2, exitGateEast3;
    private final Map<VEHICLE_TYPE, Integer> groundFloorPriorityMap = Map.ofEntries(
            Map.entry(BUS, 1),
            Map.entry(LORRY, 1),
            Map.entry(MINIBUS, 1),
            Map.entry(MINI_LORRY, 1),
            Map.entry(VAN, 2),
            Map.entry(CAR, 2),
            Map.entry(MOTORBIKE, 3)
    );

    private final Map<VEHICLE_TYPE, Integer> floor1stTo2ndPriorityMap = Map.ofEntries(
            Map.entry(VAN, 1),
            Map.entry(CAR, 2),
            Map.entry(MOTORBIKE, 3)
    );

    private final Map<VEHICLE_TYPE, Integer> floors3rdTo6thPriorityMap = Map.ofEntries(
            Map.entry(VAN, 1),
            Map.entry(CAR, 1),
            Map.entry(MOTORBIKE, 2)
    );

    private final Map<VEHICLE_TYPE, Integer> floors7thUpwardsPriorityMap = Map.ofEntries(
            Map.entry(CAR, 1)
    );

    public PettahMultiStoryCarParkManager() {
        PriorityBlockingQueue<Vehicle> entryQueue1, entryQueue2, entryQueue3, entryQueue4, entryQueue5;

        // init floors
        for (int i=0; i<NUMBER_OF_FLOORS; i++) {
            // set vehicle priority map
            floors[i] = new Floor(i, getPriorityMap(i));
        }

        // init history
        history = new History();

        // initialize entry queues
        entryQueue1 = new PriorityBlockingQueue<>(ENTRY_GATE_QUEUE_CAPACITY,
                new PriorityComparator(groundFloorPriorityMap));
        entryQueue2 = new PriorityBlockingQueue<>(ENTRY_GATE_QUEUE_CAPACITY,
                new PriorityComparator(groundFloorPriorityMap));
        entryQueue3 = new PriorityBlockingQueue<>(ENTRY_GATE_QUEUE_CAPACITY,
                new PriorityComparator(floor1stTo2ndPriorityMap));
        entryQueue4 = new PriorityBlockingQueue<>(ENTRY_GATE_QUEUE_CAPACITY,
                new PriorityComparator(floor1stTo2ndPriorityMap));
        entryQueue5 = new PriorityBlockingQueue<>(ENTRY_GATE_QUEUE_CAPACITY,
                new PriorityComparator(floors3rdTo6thPriorityMap));

        // initialize entry gates
        entryGateNorth1 = new EntryGate(NORTH_1, entryQueue1, history);
        entryGateNorth2 = new EntryGate(NORTH_2, entryQueue2, history);
        entryGateWest1 = new EntryGate(WEST_1, entryQueue3, history);
        entryGateWest2 = new EntryGate(WEST_2, entryQueue4, history);
        entryGateWest3 = new EntryGate(WEST_3, entryQueue5, history);

        // initialize exit gates
        exitGateSouth1 = new ExitGate(SOUTH_1, history);
        exitGateSouth2 = new ExitGate(SOUTH_2, history);
        exitGateEast1 = new ExitGate(EAST_1, history);
        exitGateEast2 = new ExitGate(EAST_2, history);
        exitGateEast3 = new ExitGate(EAST_3, history);

        // open entry gates
        entryGateNorth1.start();
        entryGateNorth2.start();
        entryGateWest1.start();
        entryGateWest2.start();
        entryGateWest3.start();

        // open exit gates
        exitGateSouth1.start();
        exitGateSouth2.start();
        exitGateEast1.start();
        exitGateEast2.start();
        exitGateEast3.start();

        System.out.println("LOG: Instantiated Car Park Manager ...");
    }

    @Override
    public void park(ENTRY_GATE entryGate, Vehicle vehicle) {
        switch (entryGate) {
            case NORTH_1: {
                if (entryGateNorth1.isGateAllowed(vehicle.getVehicleType())) {
                    entryGateNorth1.add(vehicle);
                } else {
                    System.out.printf("Vehicle Type: %s is not allowed with NorthGate-1%n",
                            vehicle.getVehicleType().name());
                }
                break;
            }
            case NORTH_2: {
                if (entryGateNorth2.isGateAllowed(vehicle.getVehicleType())) {
                    entryGateNorth2.add(vehicle);
                } else {
                    System.out.printf("Vehicle Type: %s is not allowed with NorthGate-2%n",
                            vehicle.getVehicleType().name());
                }
                break;
            }
            case WEST_1: {
                if (entryGateWest1.isGateAllowed(vehicle.getVehicleType())) {
                    entryGateWest1.add(vehicle);
                } else {
                    System.out.printf("Vehicle Type: %s is not allowed with WestGate-1%n",
                            vehicle.getVehicleType().name());
                }
                break;
            }
            case WEST_2: {
                if (entryGateWest2.isGateAllowed(vehicle.getVehicleType())) {
                    entryGateWest2.add(vehicle);
                } else {
                    System.out.printf("Vehicle Type: %s is not allowed with WestGate-2%n",
                            vehicle.getVehicleType().name());
                }
                break;
            }
            case WEST_3: {
                if (entryGateWest3.isGateAllowed(vehicle.getVehicleType())) {
                    entryGateWest3.add(vehicle);
                } else {
                    System.out.printf("Vehicle Type: %s is not allowed with WestGate-3%n",
                            vehicle.getVehicleType().name());
                }
                break;
            }
            default:
                throw new RuntimeException("Unknown entry gate!");
        }
    }

    @Override
    public void leave(EXIT_GATE exitGate, Vehicle vehicle) {
        switch (exitGate) {
            case SOUTH_1: {
                exitGateSouth1.add(vehicle);
                break;
            }
            case SOUTH_2: {
                exitGateSouth2.add(vehicle);
                break;
            }
            case EAST_1: {
                exitGateEast1.add(vehicle);
                break;
            }
            case EAST_2: {
                exitGateEast2.add(vehicle);
                break;
            }
            case EAST_3: {
                exitGateEast3.add(vehicle);
                break;
            }
            default:
                throw new RuntimeException("Unknown entry gate!");
        }
    }

    @Override
    public void getCurrentlyParkedVehicles() {
        System.out.printf("\n***** No. of vehicles currently parked: %d *****\n",
                currentlyParkedVehicleCount);
    }

    @Override
    public void percentageOfDifferentTypesOfVehicleCurrentlyParked() {
        Map<VEHICLE_TYPE, Integer> map = new HashMap<>();

        map.put(BUS, 0);
        map.put(LORRY, 0);
        map.put(MINIBUS, 0);
        map.put(MINI_LORRY, 0);
        map.put(VAN, 0);
        map.put(CAR, 0);
        map.put(MOTORBIKE, 0);

        synchronized (floors) {
            for (Floor floor: floors) {
                for (Slot slot: floor.getSlots()) {
                    if (slot.getOccupiedStatus() != null && slot.getOccupiedStatus() != OCCUPIED_STATUS.EMPTY) {
                        map.put(slot.getOccupiedBy(), map.get(slot.getOccupiedBy()) + 1);
                    }
                }
            }
        }

        System.out.print("\n***** Percentage Of Different Types Of Vehicle Currently Parked *****\n");
        int total = 0;
        for (Map.Entry<VEHICLE_TYPE, Integer> entry: map.entrySet()) {
            total += entry.getValue();
        }

        for (Map.Entry<VEHICLE_TYPE, Integer> entry: map.entrySet()) {
            System.out.printf("%s-> %.2f%s\n", entry.getKey().name(), (entry.getValue() / (float) total) * 100, "%s");
        }
    }

    @Override
    public void longestTimeVehicleCurrentlyInPark() {
        Vehicle vehicle = history.getLongestVehicleCurrentlyParked();
        System.out.print("\n***** Longest TIme Vehicle Currently Parked *****\n");
        System.out.printf("ID Plate: %s | Vehicle Type: %s | Entry Time: %s | Time: %.2f hours\n",
                vehicle.getIdPlate(),
                vehicle.getVehicleType().name(),
                vehicle.getEntryTime(),
                Utils.getHoursDifference(vehicle.getEntryTime(), new DateTime()));
    }

    @Override
    public void lastVehicleParked() {
        Vehicle vehicle = history.lastVehicleParked();
        System.out.print("\n***** Last Vehicle Parked *****\n");
        System.out.printf("ID Plate: %s | Vehicle Type: %s | Entry Time: %s\n", vehicle.getIdPlate(),
                vehicle.getVehicleType().name(), vehicle.getEntryTime());
    }

    @Override
    public void checkInHistory(DateTime date) {
        System.out.printf("\n***** Parked History DATE: %s *****\n", date);
        List<Vehicle> vehicles = history.getVehicles(date);

        if (vehicles == null || vehicles.isEmpty())
            System.out.println("No vehicles were parked on this day!");

        for (Vehicle vehicle: vehicles) {
            System.out.printf("ID Plate: %s | Vehicle Type: %s | Time: %.2f\n", vehicle.getIdPlate(),
                    vehicle.getVehicleType().name(), Utils.getHoursDifference(vehicle.getExitTime(), new DateTime()));
        }
    }

    @Override
    public void close() {
        // close opened entry gates
        entryGateNorth1.setRunning(false);
        entryGateNorth2.setRunning(false);
        entryGateWest1.setRunning(false);
        entryGateWest2.setRunning(false);
        entryGateWest3.setRunning(false);

        // close opened exit gates
        exitGateSouth1.setRunning(false);
        exitGateSouth2.setRunning(false);
        exitGateEast1.setRunning(false);
        exitGateEast2.setRunning(false);
        exitGateEast3.setRunning(false);

        System.out.println("LOG: Closed Car Park Manager ...");
    }

    private Map<VEHICLE_TYPE, Integer> getPriorityMap(int floorNo) {
        if (floorNo == 0)
            return groundFloorPriorityMap;
        else if (floorNo <= 2)
            return floor1stTo2ndPriorityMap;
        else if (floorNo <= 6)
            return floors3rdTo6thPriorityMap;
        else if (floorNo <= 8)
            return floors7thUpwardsPriorityMap;
        throw new RuntimeException("Unknown floor no!");
    }

    public static synchronized void incrementParkedVehiclesCount() {
        currentlyParkedVehicleCount++;
    }

    public static synchronized void decrementParkedVehiclesCount() {
        currentlyParkedVehicleCount--;
    }
}

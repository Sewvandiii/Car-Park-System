package com.task.vehicle;

import com.task.util.DateTime;
import com.task.constants.ENTRY_GATE;
import com.task.model.Owner;
import com.task.constants.VEHICLE_TYPE;

public class Bus extends Vehicle {
    public Bus(String idPlate, String model, Owner owner, ENTRY_GATE entryGate, DateTime entryTime) {
        super(idPlate, model, owner, entryGate, entryTime);
        setSpaceNeeded(5 * 3);
        setVehicleType(VEHICLE_TYPE.BUS);
    }
}

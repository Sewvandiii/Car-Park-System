package com.task.vehicle;

import com.task.constants.ENTRY_GATE;
import com.task.constants.EXIT_GATE;
import com.task.constants.VEHICLE_TYPE;
import com.task.model.Owner;
import com.task.util.DateTime;

import java.util.Arrays;
import java.util.Objects;

import static com.task.constants.EXIT_GATE.*;

public abstract class Vehicle {
    private final String idPlate;
    private final String model;
    private final DateTime entryTime;
    private DateTime exitTime;
    private int spaceNeeded;
    private final Owner owner;
    private VEHICLE_TYPE vehicleType;
    private int floorNo;
    private int[] slotNos;
    private int charge;
    private float numberOfHoursParked;
    private ENTRY_GATE entryGate;
    private EXIT_GATE exitGate;

    public Vehicle(String idPlate, String model, Owner owner, ENTRY_GATE entryGate, DateTime entryTime) {
        this.idPlate = idPlate;
        this.model = model;
        this.owner = owner;
        this.entryGate = entryGate;
        this.entryTime = entryTime;
        exitTime = null;

        // set exit gate
        switch (entryGate) {
            case NORTH_1: {
                exitGate = SOUTH_1;
                break;
            }
            case NORTH_2: {
                exitGate = SOUTH_2;
                break;
            }
            case WEST_1: {
                exitGate = EAST_1;
                break;
            }
            case WEST_2: {
                exitGate = EAST_2;
                break;
            }
            case WEST_3: {
                exitGate = EAST_3;
                break;
            }
        }
    }

    public String getIdPlate() {
        return idPlate;
    }

    public String getModel() {
        return model;
    }

    public DateTime getEntryTime() {
        return entryTime;
    }

    public DateTime getExitTime() {
        return exitTime;
    }

    public void setExitTime(DateTime exitTime) {
        this.exitTime = exitTime;
    }

    public int getSpaceNeeded() {
        return spaceNeeded;
    }

    public void setSpaceNeeded(int spaceNeeded) {
        this.spaceNeeded = spaceNeeded;
    }

    public Owner getOwner() {
        return owner;
    }

    public VEHICLE_TYPE getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(VEHICLE_TYPE vehicleType) {
        this.vehicleType = vehicleType;
    }

    public int getFloorNo() {
        return floorNo;
    }

    public void setFloorNo(int floorNo) {
        this.floorNo = floorNo;
    }

    public int[] getSlotNos() {
        return slotNos;
    }

    public void setSlotNos(int[] slotNos) {
        this.slotNos = slotNos;
    }

    public int getCharge() {
        return charge;
    }

    public void setCharge(int charge) {
        this.charge = charge;
    }

    public float getNumberOfHoursParked() {
        return numberOfHoursParked;
    }

    public void setNumberOfHoursParked(float numberOfHoursParked) {
        this.numberOfHoursParked = numberOfHoursParked;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Vehicle vehicle = (Vehicle) o;
        return spaceNeeded == vehicle.spaceNeeded && floorNo == vehicle.floorNo && charge == vehicle.charge && Float.compare(vehicle.numberOfHoursParked, numberOfHoursParked) == 0 && idPlate.equals(vehicle.idPlate) && model.equals(vehicle.model) && entryTime.equals(vehicle.entryTime) && Objects.equals(exitTime, vehicle.exitTime) && owner.equals(vehicle.owner) && vehicleType == vehicle.vehicleType && Arrays.equals(slotNos, vehicle.slotNos);
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(idPlate, model, entryTime, exitTime, spaceNeeded, owner, vehicleType, floorNo, charge, numberOfHoursParked);
        result = 31 * result + Arrays.hashCode(slotNos);
        return result;
    }

    public boolean isParkedOn(DateTime date) {
        return entryTime.getYear() == date.getYear() && entryTime.getMonth() == date.getMonth()
                && entryTime.getDate() == date.getDate();
    }

    public ENTRY_GATE getEntryGate() {
        return entryGate;
    }

    public void setEntryGate(ENTRY_GATE entryGate) {
        this.entryGate = entryGate;
    }

    public EXIT_GATE getExitGate() {
        return exitGate;
    }
}

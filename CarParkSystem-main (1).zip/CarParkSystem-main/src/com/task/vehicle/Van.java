package com.task.vehicle;

import com.task.util.DateTime;
import com.task.constants.ENTRY_GATE;
import com.task.model.Owner;
import com.task.constants.VEHICLE_TYPE;

public class Van extends Vehicle {
    public Van(String idPlate, String model, Owner owner, ENTRY_GATE entryGate, DateTime entryTime) {
        super(idPlate, model, owner, entryGate, entryTime);
        setSpaceNeeded(2 * 3);
        setVehicleType(VEHICLE_TYPE.VAN);
    }
}

package com.task;

import com.task.constants.ENTRY_GATE;
import com.task.constants.EXIT_GATE;
import com.task.vehicle.Vehicle;
import com.task.util.DateTime;

public interface CarParkManager {
    void park(ENTRY_GATE entryGate, Vehicle vehicle);
    void leave(EXIT_GATE exitGate, Vehicle vehicle);
    void getCurrentlyParkedVehicles();
    void percentageOfDifferentTypesOfVehicleCurrentlyParked();
    void longestTimeVehicleCurrentlyInPark();
    void lastVehicleParked();
    void checkInHistory(DateTime date);
    void close();
}

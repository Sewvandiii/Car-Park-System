package com.task.gate;

import com.task.model.History;
import com.task.constants.EXIT_GATE;
import com.task.vehicle.Vehicle;
import com.task.util.DateTime;
import com.task.util.Utils;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import static com.task.PettahMultiStoryCarParkManager.*;

public class ExitGate extends Thread {

    private final BlockingQueue<Vehicle> queue;
    private final History history;
    private final EXIT_GATE exitGate;
    private boolean running = true;

    public ExitGate(EXIT_GATE exitGate, History history) {
        this.queue = new LinkedBlockingQueue<>();
        this.exitGate = exitGate;
        this.history = history;
    }

    public void setRunning(boolean running) {
        this.running = running;
    }

    @Override
    public void run() {
        System.out.printf("LOG: Instantiated Exit GATE-%s ...\n", exitGate.name());
        while (running) {
            try {
                Vehicle vehicle = queue.take();
                int floorNo = vehicle.getFloorNo();
                synchronized (floors) {
                    boolean isRemoved = floors[floorNo].removeVehicle(vehicle);
                    if (isRemoved) {
                        decrementParkedVehiclesCount();
                        StringBuilder slotNosFormatStr = new StringBuilder("| ");
                        for (int slotNo: vehicle.getSlotNos()) {
                            slotNosFormatStr.append(String.format("%d ", slotNo));
                        }
                        slotNosFormatStr.append("|");
                        // set exit time
                        vehicle.setExitTime(new DateTime());
                        // set charge
                        vehicle.setCharge(Utils.calculateCharge(vehicle));
                        // set number of hours parked the vehicle
                        vehicle.setNumberOfHoursParked(Utils.getHoursDifference(vehicle.getEntryTime(),
                                vehicle.getExitTime()));

                        System.out.printf("LEAVING: Vehicle ID: %s, Floor No: %d, Slot Numbers: %s, " +
                                        "Parked Time: %.2f hours, Charge: LKR %d%n",
                                vehicle.getIdPlate(), vehicle.getFloorNo(), slotNosFormatStr,
                                vehicle.getNumberOfHoursParked(), vehicle.getCharge());
                        // add to history
                        history.addToHistory(vehicle);
                    }
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void add(Vehicle vehicle) {
        queue.add(vehicle);
    }
}

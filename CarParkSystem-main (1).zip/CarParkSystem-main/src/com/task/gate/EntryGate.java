package com.task.gate;

import com.task.model.History;
import com.task.constants.ENTRY_GATE;
import com.task.constants.VEHICLE_TYPE;
import com.task.vehicle.Vehicle;

import java.util.concurrent.PriorityBlockingQueue;

import static com.task.PettahMultiStoryCarParkManager.floors;
import static com.task.PettahMultiStoryCarParkManager.incrementParkedVehiclesCount;

public class EntryGate extends Thread {

    private final PriorityBlockingQueue<Vehicle> queue;
    private final ENTRY_GATE entryGate;
    private final History history;
    private boolean running = true;

    public EntryGate(ENTRY_GATE entryGate, PriorityBlockingQueue<Vehicle> queue, History history) {
        this.entryGate = entryGate;
        this.queue = queue;
        this.history = history;
    }

    public void setRunning(boolean running) {
        this.running = running;
    }

    @Override
    public void run() {
        System.out.printf("LOG: Instantiated Entry GATE-%s ...\n", entryGate.name());
        while (running) {
            Vehicle vehicle = queue.peek();
            boolean isRemoved = queue.remove(vehicle);
            if (vehicle != null && isRemoved) {
                boolean isVehicleParked = false;
                boolean isFilled = true;
                synchronized (floors) {
                    for (int i=0; i<floors.length; i++) {
                        if (isGateAllowed(vehicle.getVehicleType()) && floors[i].isAllowed(vehicle.getVehicleType())) {
                            if(!floors[i].isFilled()) {
                                isFilled = false;
                                isVehicleParked = floors[i].addVehicle(vehicle);
                                if (isVehicleParked) {
                                    incrementParkedVehiclesCount();
                                    history.addToHistory(vehicle);

                                    StringBuilder slotNosFormatStr = new StringBuilder("| ");
                                    for (int slotNo: vehicle.getSlotNos()) {
                                        slotNosFormatStr.append(String.format("%d ", slotNo));
                                    }

                                    slotNosFormatStr.append("|");
                                    System.out.printf("RESERVED: Vehicle ID: %s, Floor No: %d, Slot Numbers: %s, " +
                                                    "Vehicle Type: %s, Model: %s, Owner: %s-%s-%s, %n",
                                            vehicle.getIdPlate(), floors[i].getFloorNo(), slotNosFormatStr,
                                            vehicle.getVehicleType().name(), vehicle.getModel(), vehicle.getOwner().getNic(),
                                            vehicle.getOwner().getName(), vehicle.getOwner().getContactNo());
                                    break;
                                }
                            }
                        }
                    }
                }

                if (isFilled || !isVehicleParked) {
                    System.out.printf("INFO: No any parking slots available for your %s%n",
                            vehicle.getVehicleType().name());
                }
            }
        }
    }

    public boolean isGateAllowed(VEHICLE_TYPE vehicleType) {
        boolean isAllowed;
        switch (entryGate) {
            case WEST_1:case WEST_2: case WEST_3: {
                switch (vehicleType) {
                    case CAR: case VAN: case MOTORBIKE: {
                        isAllowed = true;
                        break;
                    }
                    default:
                        isAllowed = false;
                }
                break;
            }
            default:
                isAllowed = true;
        }
        return isAllowed;
    }

    public void add(Vehicle vehicle) {
        queue.add(vehicle);
    }
}

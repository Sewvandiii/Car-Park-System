package com.task.model;

import com.task.constants.OCCUPIED_STATUS;
import com.task.constants.VEHICLE_TYPE;
import com.task.vehicle.Vehicle;

import java.util.Map;

public class Floor {
    private final static int MAXIMUM_NUMBER_OF_SLOTS = 60;
    private final int floorNo;
    private final Map<VEHICLE_TYPE, Integer> priority;
    private final Slot[] slots;
    private boolean filled = false;
    private boolean anyFreeSpaceOccupiedByMotorBike = false;
    private int availableSlotNoForMotorBike = -1;

    public Floor(int floorNo, Map<VEHICLE_TYPE, Integer> priority) {
        this.floorNo = floorNo;
        this.priority = priority;
        // init slots and numbering slots from 1-60
        this.slots = new Slot[MAXIMUM_NUMBER_OF_SLOTS];
        for (int i=0; i<MAXIMUM_NUMBER_OF_SLOTS; i++)
            this.slots[i] = new Slot(i, OCCUPIED_STATUS.EMPTY);
    }

    public boolean isFilled() {
        return filled;
    }

    public boolean isAllowed(VEHICLE_TYPE type) {
        return priority.containsKey(type);
    }

    public boolean addVehicle(Vehicle vehicle) {
        if (filled)
            return false;

        if(!isAllowed(vehicle.getVehicleType()))
            return false;

        // add MotorBike to already occupied slot
        if (vehicle.getVehicleType() == VEHICLE_TYPE.MOTORBIKE) {
            if (anyFreeSpaceOccupiedByMotorBike && availableSlotNoForMotorBike > -1) {
                OCCUPIED_STATUS currentOccupiedStatus = slots[availableSlotNoForMotorBike].getOccupiedStatus();
                slots[availableSlotNoForMotorBike].addVehicleId(vehicle.getIdPlate());
                vehicle.setFloorNo(floorNo);
                vehicle.setSlotNos(new int[] { availableSlotNoForMotorBike });

                switch (currentOccupiedStatus) {
                    case ONE_THIRD: {
                        slots[availableSlotNoForMotorBike].setOccupiedStatus(OCCUPIED_STATUS.TWO_THIRD);
                        break;
                    }
                    case TWO_THIRD: {
                        slots[availableSlotNoForMotorBike].setOccupiedStatus(OCCUPIED_STATUS.FULL);
                        anyFreeSpaceOccupiedByMotorBike = false;
                        availableSlotNoForMotorBike = -1;
                        break;
                    }
                }
                return true;
            }
        }

        int j = 0;
        int noOfSlots = vehicle.getSpaceNeeded() / 3;

        if (noOfSlots == 0) {
            noOfSlots = 1;
        }

        int[] slotNos = new int[noOfSlots];

        // check for empty required no of slots
        for (int i=0; i<MAXIMUM_NUMBER_OF_SLOTS; i++) {
            if (slots[i].getOccupiedStatus() == OCCUPIED_STATUS.EMPTY) {
                slotNos[j] = slots[i].getNo();
                j++;
            }

            if (j == noOfSlots)
                break;
        }

        // can park vehicle
        if (j > 0 && j == noOfSlots) {
            vehicle.setFloorNo(floorNo);
            vehicle.setSlotNos(slotNos);
            if (vehicle.getVehicleType() == VEHICLE_TYPE.MOTORBIKE) {
                slots[slotNos[0]].setOccupiedBy(VEHICLE_TYPE.MOTORBIKE);
                slots[slotNos[0]].addVehicleId(vehicle.getIdPlate());
                slots[slotNos[0]].setOccupiedStatus(OCCUPIED_STATUS.ONE_THIRD);
                anyFreeSpaceOccupiedByMotorBike = true;
                availableSlotNoForMotorBike = slotNos[0];
            } else {
                for (int i=0; i<noOfSlots; i++) {
                    slots[slotNos[i]].setOccupiedBy(vehicle.getVehicleType());
                    slots[slotNos[i]].addVehicleId(vehicle.getIdPlate());
                    slots[slotNos[i]].setOccupiedStatus(OCCUPIED_STATUS.FULL);
                }
            }
            return true;
        }

        // no slots available
        if (j == 0) {
            filled = true;
        }

        // failed to park the given vehicle
        return false;
    }

    public boolean removeVehicle(Vehicle vehicle) {
        int[] slotNos = vehicle.getSlotNos();

        if (slotNos == null || slotNos.length == 0) {
            System.out.println("ERROR: This vehicle has not occupied slot!");
            return false;
        }

        boolean isRemoved = false;
        if (vehicle.getVehicleType() == VEHICLE_TYPE.MOTORBIKE) {
            isRemoved = slots[slotNos[0]].removeVehicleId(vehicle.getIdPlate());
            return isRemoved;
        }

        for (int slotNo : slotNos) {
            isRemoved = slots[slotNo].removeVehicleId(vehicle.getIdPlate());
            slots[slotNo].emptySlot();
        }
        return isRemoved;
    }

    public int getFloorNo() {
        return floorNo;
    }

    public Slot[] getSlots() {
        return slots;
    }
}

package com.task.model;

import java.util.Objects;

public class Owner {
    private final String nic;
    private final String name;
    private final String contactNo;

    public Owner(String nic, String name, String contactNo) {
        this.nic = nic;
        this.name = name;
        this.contactNo = contactNo;
    }

    public String getNic() {
        return nic;
    }

    public String getName() {
        return name;
    }

    public String getContactNo() {
        return contactNo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Owner owner = (Owner) o;
        return nic.equals(owner.nic) && name.equals(owner.name) && contactNo.equals(owner.contactNo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nic, name, contactNo);
    }

    @Override
    public String toString() {
        return "Owner{" +
                "nic='" + nic + '\'' +
                ", name='" + name + '\'' +
                ", contactNo='" + contactNo + '\'' +
                '}';
    }
}

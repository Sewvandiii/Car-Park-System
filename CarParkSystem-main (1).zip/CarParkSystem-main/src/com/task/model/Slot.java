package com.task.model;

import com.task.constants.OCCUPIED_STATUS;
import com.task.constants.VEHICLE_TYPE;

public class Slot {
    private final int no;
    private VEHICLE_TYPE occupiedBy = null;
    private OCCUPIED_STATUS occupiedStatus;
    private String[] idPlates;

    public Slot(int no, OCCUPIED_STATUS occupiedStatus) {
        this.no = no;
        this.occupiedStatus = occupiedStatus;
    }

    public int getNo() {
        return no;
    }

    public void setOccupiedBy(VEHICLE_TYPE occupiedBy) {
        this.occupiedBy = occupiedBy;

        if (occupiedBy == VEHICLE_TYPE.MOTORBIKE) {
            idPlates = new String[3];
        } else {
            idPlates = new String[1];
        }
    }

    public void addVehicleId(String idPlate) {
        for (int i=0; i<idPlates.length; i++) {
            if (idPlates[i] == null) {
                idPlates[i] = idPlate;
                break;
            }
        }
    }

    public boolean removeVehicleId(String idPlate) {
        boolean isRemoved = false;
        if (idPlates == null)
            return false;
        for (int i=0; i<idPlates.length; i++) {
            if (idPlates[i] != null && idPlates[i].equals(idPlate)) {
                idPlates[i] = null;
                if (occupiedBy == VEHICLE_TYPE.MOTORBIKE) {
                    switch (occupiedStatus) {
                        case ONE_THIRD: {
                            isRemoved = true;
                            occupiedStatus = OCCUPIED_STATUS.EMPTY;
                            occupiedBy = null;
                            break;
                        }
                        case TWO_THIRD: {
                            isRemoved = true;
                            occupiedStatus = OCCUPIED_STATUS.ONE_THIRD;
                            break;
                        }
                        case FULL: {
                            isRemoved = true;
                            occupiedStatus = OCCUPIED_STATUS.TWO_THIRD;
                            break;
                        }
                        default:
                            throw new RuntimeException("ERROR: Logical Error On the System!");
                    }
                } else {
                    isRemoved = true;
                    idPlates = null;
                    occupiedStatus = OCCUPIED_STATUS.EMPTY;
                    occupiedBy = null;
                }
                break;
            }
        }
        return isRemoved;
    }

    public void emptySlot() {
        occupiedBy = null;
        occupiedStatus = OCCUPIED_STATUS.EMPTY;
        idPlates = null;
    }

    public OCCUPIED_STATUS getOccupiedStatus() {
        return occupiedStatus;
    }

    public void setOccupiedStatus(OCCUPIED_STATUS occupiedStatus) {
        this.occupiedStatus = occupiedStatus;
    }

    public VEHICLE_TYPE getOccupiedBy() {
        return occupiedBy;
    }
}

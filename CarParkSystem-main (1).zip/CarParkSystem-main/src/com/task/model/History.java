package com.task.model;

import com.task.vehicle.Vehicle;
import com.task.util.DateTime;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class History {
    private final List<Vehicle> vehicles;

    public History() {
        vehicles = Collections.synchronizedList(new ArrayList<>());
    }

    public void addToHistory(Vehicle vehicle) {
        for (int i=0; i<vehicles.size(); i++) {
            if (vehicle.getIdPlate().equals(vehicles.get(i).getIdPlate())) {
                vehicles.set(i, vehicle);
                break;
            }
        }
        vehicles.add(vehicle);
    }

    public List<Vehicle> getVehicles(DateTime date) {
        List<Vehicle> filteredList = new ArrayList<>();
        synchronized (vehicles) {
            for (Vehicle vehicle : vehicles) {
                if (vehicle.isParkedOn(date)) {
                    filteredList.add(vehicle);
                }
            }
        }
        return filteredList;
    }

    public List<Vehicle> getVehicles() {
        List<Vehicle> filteredList = new ArrayList<>();
        synchronized (vehicles) {
            for (Vehicle vehicle : vehicles) {
                if (vehicle.getExitTime() == null) {
                    filteredList.add(vehicle);
                }
            }
        }
        return filteredList;
    }

    public Vehicle getLongestVehicleCurrentlyParked() {
        List<Vehicle> vehicles = getVehicles();
        long min = Long.MAX_VALUE;
        int index = 0;
        int i=0;
        for (Vehicle vehicle: vehicles) {
            long seconds = vehicle.getEntryTime().getSecondInaDay();
            if (min > seconds) {
                index = i;
                min = seconds;
            }
            i++;
        }
        return vehicles.get(index);
    }

    public Vehicle lastVehicleParked() {
        int index = 0;
        int i=0;
        List<Vehicle> vehicles = getVehicles();
        long max = Long.MIN_VALUE;
        for (Vehicle vehicle: vehicles) {
            long seconds = vehicle.getEntryTime().getSecondInaDay();
            if (max < seconds) {
                index = i;
                max = seconds;
            }
            i++;
        }
        return vehicles.get(index);
    }
}

package com.task.constants;

public enum EXIT_GATE {
    SOUTH_1, SOUTH_2, EAST_1, EAST_2, EAST_3
}

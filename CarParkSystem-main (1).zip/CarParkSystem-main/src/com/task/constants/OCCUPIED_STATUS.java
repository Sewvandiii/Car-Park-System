package com.task.constants;

public enum OCCUPIED_STATUS {
    EMPTY, FULL, ONE_THIRD, TWO_THIRD
}

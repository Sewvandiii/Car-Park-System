package com.task.constants;

public enum VEHICLE_TYPE {
    BUS, LORRY, MINIBUS, MINI_LORRY, VAN, CAR, MOTORBIKE
}

package com.task.constants;

import java.util.List;
import java.util.Random;

public enum ENTRY_GATE {
    NORTH_1, NORTH_2, WEST_1, WEST_2, WEST_3;

    private static final List<ENTRY_GATE> VALUES = List.of(values());
    private static final int SIZE = VALUES.size();
    private static final Random RANDOM = new Random();

    public static ENTRY_GATE random()  {
        return VALUES.get(RANDOM.nextInt(SIZE));
    }
}

package com.task;

import com.task.constants.ENTRY_GATE;
import com.task.model.Owner;
import com.task.vehicle.*;
import com.task.util.DateTime;
import com.task.util.Utils;

import java.util.Random;

public class Simulation {

    private final static String[] MODELS = new String[] {"TESLA", "TOYOTA", "HONDA", "BMW", "FORD"};
    private final static int MODELS_COUNT = 5;
    private final static int RANDOM_VEHICLE_COUNT = 550;
    private static final Vehicle[] vehicles = new Vehicle[RANDOM_VEHICLE_COUNT];
    private final static Random random = new Random();

    private static void initRandom() {
        for (int i=0; i<RANDOM_VEHICLE_COUNT; i++) {
            ENTRY_GATE gate = ENTRY_GATE.random();
            vehicles[i] = getRandomVehicleForGate(gate,
                            String.valueOf(i+1),
                            MODELS[random.nextInt(MODELS_COUNT)],
                            new Owner("NIC - " + (i+1), "Name - " + (i+1), "Contact No - " + (i+1))
            );
        }
    }

    private static Vehicle getRandomVehicleForGate(ENTRY_GATE gate, String idPlate, String model, Owner owner) {
        switch (gate) {
            case NORTH_1:case NORTH_2: {
                int selectedIndex = random.nextInt(7);
                if (selectedIndex == 0) {
                    return new Bus(idPlate, model, owner, gate, new DateTime());
                } else if (selectedIndex == 1) {
                    return new Lorry(idPlate, model, owner, gate, new DateTime());
                } else if (selectedIndex == 2) {
                    return new Minibus(idPlate, model, owner, gate, new DateTime());
                } else if (selectedIndex == 3) {
                    return new MiniLorry(idPlate, model, owner, gate, new DateTime());
                } else if (selectedIndex == 4) {
                    return new Van(idPlate, model, owner, gate, new DateTime());
                } else if (selectedIndex == 5) {
                    return new Car(idPlate, model, owner, gate, new DateTime());
                } else {
                    return new Motorbike(idPlate, model, owner, gate, new DateTime());
                }
            }
            case WEST_1:case WEST_2: case WEST_3: {
                int selectedIndex = random.nextInt(3);
                if (selectedIndex == 0) {
                    return new Car(idPlate, model, owner, gate, new DateTime());
                } else if (selectedIndex == 1) {
                    return new Van(idPlate, model, owner, gate, new DateTime());
                } else {
                    return new Motorbike(idPlate, model, owner, gate, new DateTime());
                }
            }
            default:
                throw new RuntimeException("Unknown entry gate!");
        }
    }

    public static void main(String[] args) throws InterruptedException {
        // add multiplier for charging (This is only for testing)
        Utils.setMULTIPLIER(100);
        // create vehicles randomly for simulation
        initRandom();
        // init car park manager
        CarParkManager park = new PettahMultiStoryCarParkManager();
        Thread.sleep(1000);

        for (int p=1; p<=5; p++) {
            // add vehicles to car park
            for (int i=((p-1) * 100); i<(p * 100); i++) {
                park.park(vehicles[i].getEntryGate(), vehicles[i]);
            }

            Thread.sleep(1000);

            // leave vehicles from car park manager
            for (int i=((p-1) * 80); i<(p * 80); i++) {
                park.leave(vehicles[i].getExitGate(), vehicles[i]);
            }

            Thread.sleep(1000);

            // get currently parked vehicles
            park.getCurrentlyParkedVehicles();

            // Percentage Of Different Types Of Vehicle Currently Parked
            park.percentageOfDifferentTypesOfVehicleCurrentlyParked();

            // get the longest time vehicle currently parked
            park.longestTimeVehicleCurrentlyInPark();

            // last vehicle parked
            park.lastVehicleParked();
        }

        // close the park after 5 seconds
        Thread.sleep(5000);

        // close the car park manager
        park.close();

        System.exit(0);
    }
}

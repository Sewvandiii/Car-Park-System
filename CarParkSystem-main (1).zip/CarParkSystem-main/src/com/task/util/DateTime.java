package com.task.util;

import java.util.Calendar;

public class DateTime implements Comparable<DateTime> {
    private int year;
    private int month;
    private int date;
    private int hours;
    private int minutes;
    private int seconds;
    private final static long SECONDS_FOR_MINUTE = 60;
    private final static long SECONDS_FOR_HOUR = 60 * 60;
    private final static long SECONDS_FOR_DAY = 24 * 60 * 60;

    public DateTime() {
        // set today date
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        year = calendar.get(Calendar.YEAR);
        month = calendar.get(Calendar.MONTH);
        date = calendar.get(Calendar.DATE);
        hours = calendar.get(Calendar.HOUR);
        minutes = calendar.get(Calendar.MINUTE);
        seconds = calendar.get(Calendar.SECOND);
    }

    public DateTime(int year, int month, int date) {
        this.year = year;
        this.month = month;
        this.date = date;
        this.hours = 0;
        this.minutes = 0;
        this.seconds = 0;
    }

    public DateTime(int year, int month, int date, int hours, int minutes, int seconds) {
        this.year = year;
        this.month = month;
        this.date = date;
        this.hours = hours;
        this.minutes = minutes;
        this.seconds = seconds;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        if(Math.log10(year) + 1 > 4) {
            System.out.println("Invalid input for a year!");
        }else {
            this.year = year;
        }
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        if(month > 0 && month < 12) {
            this.month = month;
        }else {
            throw new IllegalArgumentException("Invalid input for a month!");
        }
    }

    public int getDate() {
        return date;
    }

    public void setDate(int date) {
        if(getYear() % 400 == 0 && getMonth() == 2) {
            if(date < 30) {
                this.date = date;
            } else {
                throw new IllegalArgumentException("This is a leap year and this month has only 29 days!");
            }
        } else if(!(getYear() % 400 == 0) && getMonth() == 2) {
            if(date < 29) {
                this.date = date;
            } else {
                throw new IllegalArgumentException("Invalid input for a date");
            }
        } else {
            this.date = date;
        }
    }

    public int getHours() {
        return hours;
    }

    public void setHours(int hours) {
        if(hours > 0 && hours < 24) {
            this.hours = hours;
        } else {
            throw new IllegalArgumentException("Invalid input for a hour!");
        }
    }

    public int getMinutes() {
        return minutes;
    }

    public void setMinutes(int minutes) {
        if(minutes < 60) {
            this.minutes = minutes;
        }else {
            throw new IllegalArgumentException("Invalid input for minutes!");
        }
    }

    public int getSeconds() {
        return seconds;
    }

    public void setSeconds(int seconds) {
        if(seconds < 60) {
            this.seconds = seconds;
        }else {
            throw new IllegalArgumentException("Invalid input for  seconds!");
        }
    }

    private boolean isLeapYear() {
        return  ((getYear() % 4 == 0 && getYear() % 100 != 0) || (getYear() % 400 == 0));
    }

    private int noOfDaysForMonth() {
        int daysCount = 0;
        switch (getMonth()) {
            case 1: case 3: case 5: case 7: case 8: case 10: case 12:
                daysCount = 31;
                break;
            case 4: case 6: case 9: case 11:
                daysCount = 30;
                break;
            case 2:
                daysCount = isLeapYear() ? 29 : 28;
                break;
        }
        return daysCount;
    }

    private int noOfDaysForYear() {
        return isLeapYear() ? 366 : 365;
    }

    public long getSecondInaDay() {
        return  this.year * noOfDaysForYear() * SECONDS_FOR_DAY +
                this.month * noOfDaysForMonth() * SECONDS_FOR_DAY +
                this.date * SECONDS_FOR_DAY +
                this.hours * SECONDS_FOR_HOUR +
                this.minutes * SECONDS_FOR_MINUTE +
                this.seconds;
    }

    @Override
    public int compareTo(DateTime o) {
        return (int) (this.getSecondInaDay() - o.getSecondInaDay());
    }

    @Override
    public String toString() {
        return String.format("%d/%d/%d %d:%d:%d", year, month + 1, date, hours, minutes, seconds);
    }
}
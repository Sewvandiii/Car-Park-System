package com.task.util;

import com.task.vehicle.Vehicle;

public final class Utils {
    private static final int CHARGE_PER_SPACE_PER_HOUR_FOR_FIRST_THREE_HOURS = 50;
    private static final int CHARGE_PER_SPACE_PER_HOUR_FOR_ADDITIONAL_HOURS = 50;
    private static final int MAXIMUM_CHARGE_FOR_A_DAY = 1200;
    private static final int SECONDS_FOR_HOUR = 60 * 60;
    // This is for testing
    private static int MULTIPLIER = 1;

    public static int calculateCharge(Vehicle vehicle) {
        float charge;
        float space = vehicle.getSpaceNeeded() / 3f;
        float hours = getHoursDifference(vehicle.getEntryTime(), vehicle.getExitTime());
        if (hours <= 3.0) {
            charge = space * hours * CHARGE_PER_SPACE_PER_HOUR_FOR_FIRST_THREE_HOURS;
        } else {
            charge = space * 3 * CHARGE_PER_SPACE_PER_HOUR_FOR_FIRST_THREE_HOURS +
                    space * (hours - 3) * CHARGE_PER_SPACE_PER_HOUR_FOR_ADDITIONAL_HOURS;
        }

        if (MAXIMUM_CHARGE_FOR_A_DAY < charge)
            return MAXIMUM_CHARGE_FOR_A_DAY;
        else
            return Math.round(MULTIPLIER * charge);
    }

    public static float getHoursDifference(DateTime time1, DateTime time2) {
        return Math.abs((int) (time1.getSecondInaDay() - time2.getSecondInaDay()) * MULTIPLIER) / (float) SECONDS_FOR_HOUR;
    }

    public static void setMULTIPLIER(int MULTIPLIER) {
        Utils.MULTIPLIER = MULTIPLIER;
    }
}
